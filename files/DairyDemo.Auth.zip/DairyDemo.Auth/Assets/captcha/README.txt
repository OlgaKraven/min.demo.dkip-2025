Place 4 puzzle image files here: 1.png, 2.png, 3.png, 4.png
Images should be square fragments of one image (e.g. 2x2 grid).