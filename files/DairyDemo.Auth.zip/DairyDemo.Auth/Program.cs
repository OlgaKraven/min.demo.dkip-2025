using DairyDemo.Auth.UI.Forms;
namespace DairyDemo.Auth;
internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new LoginForm());
    }
}