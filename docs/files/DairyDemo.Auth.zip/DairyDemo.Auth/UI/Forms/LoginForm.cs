using DairyDemo.Auth.Services;
using DairyDemo.Auth.UI.Controls;

namespace DairyDemo.Auth.UI.Forms;

public sealed class LoginForm : Form
{
    private readonly AuthService          _auth       = new();
    private readonly TextBox              _tbLogin    = new() { PlaceholderText = "Логин",  Width = 220 };
    private readonly TextBox              _tbPassword = new() { PlaceholderText = "Пароль", Width = 220, UseSystemPasswordChar = true };
    private readonly Button               _btnLogin   = new() { Text = "Войти", Width = 220 };
    private readonly CaptchaPuzzleControl _captcha    = new() { Width = 220, Height = 220 };

    public LoginForm()
    {
        Text            = "Авторизация";
        Size            = new Size(300, 480);
        StartPosition   = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox     = false;

        var layout = new FlowLayoutPanel
        {
            Dock          = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            Padding       = new Padding(30, 20, 0, 0),
            WrapContents  = false,
        };
        layout.Controls.Add(new Label { Text = "Вход в систему", Font = new Font("Segoe UI", 14, FontStyle.Bold), AutoSize = true });
        layout.Controls.Add(new Label { Text = "Логин:",   AutoSize = true });
        layout.Controls.Add(_tbLogin);
        layout.Controls.Add(new Label { Text = "Пароль:",  AutoSize = true });
        layout.Controls.Add(_tbPassword);
        layout.Controls.Add(new Label { Text = "Соберите изображение:", AutoSize = true });
        layout.Controls.Add(_captcha);
        layout.Controls.Add(_btnLogin);
        Controls.Add(layout);

        var captchaPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "captcha");
        _captcha.LoadImages(captchaPath);
        _btnLogin.Click += OnLoginClick;
    }

    private async void OnLoginClick(object? sender, EventArgs e)
    {
        _btnLogin.Enabled = false;
        try
        {
            var (ok, message, user) = await _auth.LoginAsync(
                _tbLogin.Text.Trim(), _tbPassword.Text, _captcha.IsSolved);

            MessageBox.Show(message, "Авторизация", MessageBoxButtons.OK,
                ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (ok && user is not null)
            {
                Form next = user.Role == "admin" ? new AdminForm(user) : new UserForm(user);
                Hide();
                next.FormClosed += (_, _) => Close();
                next.Show();
            }
            else
            {
                _captcha.Reset();
                _tbPassword.Clear();
            }
        }
        finally { _btnLogin.Enabled = true; }
    }
}
