using DairyDemo.Auth.Data.Models;
using DairyDemo.Auth.Data.Repositories;
using DairyDemo.Auth.Services;

namespace DairyDemo.Auth.UI.Forms;

public sealed class AdminForm : Form
{
    private readonly UserRepository _repo      = new();
    private readonly DataGridView   _grid      = new() { Dock = DockStyle.Fill, ReadOnly = true, SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false };
    private readonly Button         _btnAdd    = new() { Text = "Добавить",        Width = 130 };
    private readonly Button         _btnEdit   = new() { Text = "Изменить",         Width = 130 };
    private readonly Button         _btnPwd    = new() { Text = "Сменить пароль",   Width = 130 };
    private readonly Button         _btnUnlock = new() { Text = "Снять блокировку", Width = 150 };
    private readonly Button         _btnRefresh= new() { Text = "Обновить",         Width = 100 };

    public AdminForm(User admin)
    {
        Text          = $"Панель администратора — {admin.Login}";
        Size          = new Size(720, 480);
        StartPosition = FormStartPosition.CenterScreen;

        _grid.AutoGenerateColumns = false;
        _grid.Columns.Add(new DataGridViewTextBoxColumn  { DataPropertyName = "Id",             HeaderText = "ID",      Width = 50  });
        _grid.Columns.Add(new DataGridViewTextBoxColumn  { DataPropertyName = "Login",          HeaderText = "Логин",   Width = 160 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn  { DataPropertyName = "Role",           HeaderText = "Роль",    Width = 80  });
        _grid.Columns.Add(new DataGridViewTextBoxColumn  { DataPropertyName = "FailedAttempts", HeaderText = "Попытки", Width = 70  });
        _grid.Columns.Add(new DataGridViewCheckBoxColumn { DataPropertyName = "IsLocked",       HeaderText = "Заблок.", Width = 70  });

        var btnPanel = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 45, FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(5) };
        btnPanel.Controls.AddRange(new Control[] { _btnAdd, _btnEdit, _btnPwd, _btnUnlock, _btnRefresh });
        Controls.Add(_grid);
        Controls.Add(btnPanel);

        _btnAdd.Click     += OnAddClick;
        _btnEdit.Click    += OnEditClick;
        _btnPwd.Click     += OnChangePwdClick;
        _btnUnlock.Click  += OnUnlockClick;
        _btnRefresh.Click += async (_, _) => await LoadUsersAsync();
        Load              += async (_, _) => await LoadUsersAsync();
    }

    private async Task LoadUsersAsync() => _grid.DataSource = await _repo.GetAllAsync();

    private User? GetSelectedUser() =>
        _grid.SelectedRows.Count == 0 ? null : _grid.SelectedRows[0].DataBoundItem as User;

    private async void OnAddClick(object? sender, EventArgs e)
    {
        using var dlg = new UserEditDialog(null);
        if (dlg.ShowDialog(this) != DialogResult.OK) return;
        if (await _repo.ExistsLoginAsync(dlg.Login))
        {
            MessageBox.Show("Пользователь с таким логином уже существует.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        await _repo.AddUserAsync(dlg.Login, PasswordService.HashPassword(dlg.Password), dlg.Role);
        await LoadUsersAsync();
    }

    private async void OnEditClick(object? sender, EventArgs e)
    {
        var user = GetSelectedUser();
        if (user is null) { MessageBox.Show("Выберите пользователя."); return; }
        using var dlg = new UserEditDialog(user);
        if (dlg.ShowDialog(this) != DialogResult.OK) return;
        if (await _repo.ExistsLoginAsync(dlg.Login, user.Id))
        {
            MessageBox.Show("Пользователь с таким логином уже существует.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        await _repo.UpdateUserAsync(user.Id, dlg.Login, dlg.Role);
        await LoadUsersAsync();
    }

    private async void OnChangePwdClick(object? sender, EventArgs e)
    {
        var user = GetSelectedUser();
        if (user is null) { MessageBox.Show("Выберите пользователя."); return; }
        using var dlg = new PasswordDialog();
        if (dlg.ShowDialog(this) != DialogResult.OK || string.IsNullOrWhiteSpace(dlg.Password)) return;
        await _repo.UpdatePasswordAsync(user.Id, PasswordService.HashPassword(dlg.Password));
        MessageBox.Show("Пароль изменён.", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private async void OnUnlockClick(object? sender, EventArgs e)
    {
        var user = GetSelectedUser();
        if (user is null) { MessageBox.Show("Выберите пользователя."); return; }
        await _repo.UnlockAsync(user.Id);
        MessageBox.Show($"Блокировка с пользователя «{user.Login}» снята.", "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
        await LoadUsersAsync();
    }
}

internal sealed class UserEditDialog : Form
{
    public string Login    { get; private set; } = "";
    public string Password { get; private set; } = "";
    public string Role     { get; private set; } = "user";

    private readonly TextBox  _tbLogin = new() { Width = 200 };
    private readonly TextBox  _tbPwd   = new() { Width = 200, UseSystemPasswordChar = true };
    private readonly ComboBox _cbRole  = new() { Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly bool     _isEdit;

    public UserEditDialog(User? existing)
    {
        _isEdit         = existing is not null;
        Text            = _isEdit ? "Изменить пользователя" : "Добавить пользователя";
        Size            = new Size(310, 230);
        StartPosition   = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox     = false;

        _cbRole.Items.AddRange(new object[] { "user", "admin" });
        _cbRole.SelectedIndex = 0;

        if (existing is not null)
        {
            _tbLogin.Text        = existing.Login;
            _cbRole.SelectedItem = existing.Role;
        }

        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 4, Padding = new Padding(10) };
        layout.Controls.Add(new Label { Text = "Логин:",  AutoSize = true, Anchor = AnchorStyles.Right }, 0, 0);
        layout.Controls.Add(_tbLogin, 1, 0);
        layout.Controls.Add(new Label { Text = "Пароль:", AutoSize = true, Anchor = AnchorStyles.Right }, 0, 1);
        layout.Controls.Add(_tbPwd,   1, 1);
        layout.Controls.Add(new Label { Text = "Роль:",   AutoSize = true, Anchor = AnchorStyles.Right }, 0, 2);
        layout.Controls.Add(_cbRole,  1, 2);

        var btnOk     = new Button { Text = "ОК",     DialogResult = DialogResult.OK,     Width = 90 };
        var btnCancel = new Button { Text = "Отмена", DialogResult = DialogResult.Cancel, Width = 90 };
        btnOk.Click  += OnOkClick;
        AcceptButton  = btnOk;
        CancelButton  = btnCancel;

        var btnRow = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
        btnRow.Controls.Add(btnCancel);
        btnRow.Controls.Add(btnOk);
        layout.Controls.Add(btnRow, 1, 3);
        Controls.Add(layout);
    }

    private void OnOkClick(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(_tbLogin.Text))
        {
            MessageBox.Show("Введите логин.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            DialogResult = DialogResult.None;
            return;
        }
        if (!_isEdit && string.IsNullOrWhiteSpace(_tbPwd.Text))
        {
            MessageBox.Show("Введите пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            DialogResult = DialogResult.None;
            return;
        }
        Login    = _tbLogin.Text.Trim();
        Password = _tbPwd.Text;
        Role     = _cbRole.SelectedItem?.ToString() ?? "user";
    }
}

internal sealed class PasswordDialog : Form
{
    public string Password { get; private set; } = "";
    private readonly TextBox _tbPwd = new() { Width = 200, UseSystemPasswordChar = true };

    public PasswordDialog()
    {
        Text            = "Смена пароля";
        Size            = new Size(280, 140);
        StartPosition   = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox     = false;

        var btnOk     = new Button { Text = "ОК",     DialogResult = DialogResult.OK,     Width = 80 };
        var btnCancel = new Button { Text = "Отмена", DialogResult = DialogResult.Cancel, Width = 80 };
        btnOk.Click  += (_, _) => Password = _tbPwd.Text;
        AcceptButton  = btnOk;
        CancelButton  = btnCancel;

        var layout = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, Padding = new Padding(10) };
        layout.Controls.Add(new Label { Text = "Новый пароль:", AutoSize = true });
        layout.Controls.Add(_tbPwd);
        var btnRow = new FlowLayoutPanel { FlowDirection = FlowDirection.LeftToRight, AutoSize = true };
        btnRow.Controls.Add(btnOk);
        btnRow.Controls.Add(btnCancel);
        layout.Controls.Add(btnRow);
        Controls.Add(layout);
    }
}
