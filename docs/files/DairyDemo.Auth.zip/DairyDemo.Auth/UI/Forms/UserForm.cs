using DairyDemo.Auth.Data.Models;

namespace DairyDemo.Auth.UI.Forms;

public sealed class UserForm : Form
{
    public UserForm(User user)
    {
        Text            = "Рабочий стол пользователя";
        Size            = new Size(400, 200);
        StartPosition   = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox     = false;

        var layout = new FlowLayoutPanel
        {
            Dock          = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            Padding       = new Padding(30, 20, 0, 0),
            WrapContents  = false,
        };
        layout.Controls.Add(new Label { Text = $"Добро пожаловать, {user.Login}!", Font = new Font("Segoe UI", 13, FontStyle.Bold), AutoSize = true });
        layout.Controls.Add(new Label { Text = $"Роль: {user.Role}", AutoSize = true });

        var btnLogout = new Button { Text = "Выход", Width = 120 };
        btnLogout.Click += (_, _) => Close();
        layout.Controls.Add(btnLogout);
        Controls.Add(layout);
    }
}
