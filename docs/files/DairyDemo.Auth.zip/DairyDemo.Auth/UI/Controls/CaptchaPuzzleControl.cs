namespace DairyDemo.Auth.UI.Controls;

/// <summary>
/// Капча-пазл 2x2. IsSolved == true когда все фрагменты на своих местах.
/// </summary>
public sealed class CaptchaPuzzleControl : UserControl
{
    private const int Cols      = 2;
    private const int Rows      = 2;
    private const int TileCount = Cols * Rows;

    private readonly PictureBox[] _tiles     = new PictureBox[TileCount];
    private readonly int[]        _order     = new int[TileCount];
    private readonly Image?[]     _originals = new Image?[TileCount]; // FIXED: store originals
    private int _selectedIndex = -1;

    public bool IsSolved =>
        _order[0] == 0 && _order[1] == 1 &&
        _order[2] == 2 && _order[3] == 3;

    public CaptchaPuzzleControl()
    {
        DoubleBuffered = true;
        InitTiles();
        Shuffle();
    }

    private void InitTiles()
    {
        var layout = new TableLayoutPanel
        {
            Dock        = DockStyle.Fill,
            ColumnCount = Cols,
            RowCount    = Rows,
            Padding     = Padding.Empty,
            Margin      = Padding.Empty,
        };
        for (int c = 0; c < Cols; c++)
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
        for (int r = 0; r < Rows; r++)
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));

        for (int i = 0; i < TileCount; i++)
        {
            var pb = new PictureBox
            {
                Dock      = DockStyle.Fill,
                SizeMode  = PictureBoxSizeMode.StretchImage,
                Margin    = new Padding(2),
                BackColor = Color.LightGray,
                Tag       = i,
            };
            pb.Click += OnTileClick;
            _tiles[i] = pb;
            layout.Controls.Add(pb, i % Cols, i / Cols);
        }
        Controls.Add(layout);
    }

    public void LoadImages(string folder)
    {
        for (int i = 0; i < TileCount; i++)
        {
            var path = Path.Combine(folder, $"{i + 1}.png");
            _originals[i] = File.Exists(path) ? Image.FromFile(path) : null;
        }
        Shuffle();
    }

    public void Shuffle()
    {
        var rng = new Random();
        for (int i = 0; i < TileCount; i++) _order[i] = i;
        do
        {
            for (int i = TileCount - 1; i > 0; i--)
            {
                int j = rng.Next(i + 1);
                (_order[i], _order[j]) = (_order[j], _order[i]);
            }
        } while (IsSolved);

        ApplyOrder();
        _selectedIndex = -1;
    }

    // FIXED: uses _originals instead of current tile images to avoid accumulated drift
    private void ApplyOrder()
    {
        for (int i = 0; i < TileCount; i++)
            _tiles[i].Image = _originals[_order[i]];
    }

    private void OnTileClick(object? sender, EventArgs e)
    {
        if (sender is not PictureBox pb) return;
        int clickedIndex = Array.IndexOf(_tiles, pb);

        if (_selectedIndex == -1)
        {
            _selectedIndex = clickedIndex;
            pb.BackColor   = Color.Yellow;
        }
        else
        {
            (_order[_selectedIndex], _order[clickedIndex]) =
                (_order[clickedIndex], _order[_selectedIndex]);

            _tiles[_selectedIndex].BackColor = Color.LightGray;
            _selectedIndex = -1;
            ApplyOrder();
        }
    }

    public void Reset()
    {
        Shuffle();
        foreach (var t in _tiles) t.BackColor = Color.LightGray;
    }
}
