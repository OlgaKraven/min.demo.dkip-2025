using DairyDemo.Auth.Data.Models;
using DairyDemo.Auth.Data.Repositories;

namespace DairyDemo.Auth.Services;

public sealed class AuthService
{
    private readonly UserRepository _repo = new();

    public async Task<(bool ok, string message, User? user)> LoginAsync(
        string login, string password, bool captchaOk)
    {
        var user = await _repo.GetByLoginAsync(login);

        if (user is null)
            return (false, "Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные", null);

        if (user.IsLocked)
            return (false, "Вы заблокированы. Обратитесь к администратору", null);

        if (!captchaOk)
        {
            await _repo.IncrementFailedAttemptsAndLockIfNeededAsync(user.Id);
            return (false, "Соберите изображение для подтверждения", null);
        }

        if (!PasswordService.Verify(password, user.PasswordHash))
        {
            await _repo.IncrementFailedAttemptsAndLockIfNeededAsync(user.Id);
            var updated = await _repo.GetByLoginAsync(login);
            if (updated?.IsLocked == true)
                return (false, "Вы заблокированы. Обратитесь к администратору", null);
            return (false, "Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные", null);
        }

        await _repo.ResetFailedAttemptsAsync(user.Id);
        return (true, "Вы успешно авторизовались", user);
    }
}
