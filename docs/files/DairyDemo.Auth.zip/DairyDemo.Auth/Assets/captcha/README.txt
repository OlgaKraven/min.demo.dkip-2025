Поместите сюда 4 файла: 1.png, 2.png, 3.png, 4.png
Это фрагменты одного квадратного изображения (2x2 сетка).
В свойствах каждого файла в VS: Build Action = Content, Copy to Output = PreserveNewest.
