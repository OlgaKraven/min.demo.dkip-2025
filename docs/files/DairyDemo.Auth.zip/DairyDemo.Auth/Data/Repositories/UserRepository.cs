using DairyDemo.Auth.Data.Models;
using MySqlConnector;

namespace DairyDemo.Auth.Data.Repositories;

public sealed class UserRepository
{
    public async Task<User?> GetByLoginAsync(string login)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = """
            SELECT id, login, password_hash, role, failed_attempts, is_locked
            FROM users WHERE login = @login LIMIT 1
            """;
        cmd.Parameters.AddWithValue("@login", login);
        await using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync()) return null;
        return MapUser(reader);
    }

    public async Task<List<User>> GetAllAsync()
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = """
            SELECT id, login, password_hash, role, failed_attempts, is_locked
            FROM users ORDER BY id
            """;
        var list = new List<User>();
        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
            list.Add(MapUser(reader));
        return list;
    }

    public async Task<bool> ExistsLoginAsync(string login, long excludeId = 0)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM users WHERE login = @login AND id <> @excludeId";
        cmd.Parameters.AddWithValue("@login", login);
        cmd.Parameters.AddWithValue("@excludeId", excludeId);
        return Convert.ToInt64(await cmd.ExecuteScalarAsync()) > 0;
    }

    public async Task AddUserAsync(string login, string passwordHash, string role)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = "INSERT INTO users (login, password_hash, role) VALUES (@login, @hash, @role)";
        cmd.Parameters.AddWithValue("@login", login);
        cmd.Parameters.AddWithValue("@hash",  passwordHash);
        cmd.Parameters.AddWithValue("@role",  role);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UpdateUserAsync(long id, string login, string role)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = "UPDATE users SET login = @login, role = @role WHERE id = @id";
        cmd.Parameters.AddWithValue("@login", login);
        cmd.Parameters.AddWithValue("@role",  role);
        cmd.Parameters.AddWithValue("@id",    id);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UpdatePasswordAsync(long id, string passwordHash)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = "UPDATE users SET password_hash = @hash WHERE id = @id";
        cmd.Parameters.AddWithValue("@hash", passwordHash);
        cmd.Parameters.AddWithValue("@id",   id);
        await cmd.ExecuteNonQueryAsync();
    }

    // FIXED: failed_attempts is already incremented by MySQL before IF is evaluated,
    // so IF(failed_attempts >= 3) correctly locks on the 3rd attempt.
    public async Task IncrementFailedAttemptsAndLockIfNeededAsync(long userId)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = """
            UPDATE users
            SET failed_attempts = failed_attempts + 1,
                is_locked = IF(failed_attempts >= 3, 1, 0)
            WHERE id = @id
            """;
        cmd.Parameters.AddWithValue("@id", userId);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task ResetFailedAttemptsAsync(long userId)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = "UPDATE users SET failed_attempts = 0 WHERE id = @id";
        cmd.Parameters.AddWithValue("@id", userId);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UnlockAsync(long userId)
    {
        await using var conn = Db.CreateConnection();
        await conn.OpenAsync();
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = "UPDATE users SET is_locked = 0, failed_attempts = 0 WHERE id = @id";
        cmd.Parameters.AddWithValue("@id", userId);
        await cmd.ExecuteNonQueryAsync();
    }

    private static User MapUser(MySqlDataReader r) => new()
    {
        Id             = r.GetInt64("id"),
        Login          = r.GetString("login"),
        PasswordHash   = r.GetString("password_hash"),
        Role           = r.GetString("role"),
        FailedAttempts = r.GetInt32("failed_attempts"),
        IsLocked       = r.GetBoolean("is_locked"),
    };
}
